package com.example.nikestoreapp;

public class Until {
    public static final String EMAIL ="huyendieu01112002@gmail.com";
    public static final String PASSWORD ="01666285546";
}
